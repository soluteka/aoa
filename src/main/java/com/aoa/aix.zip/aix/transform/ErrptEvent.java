package com.aoa.aix.transform;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ErrptEvent {
    private String errorId;       // ej: AA8AB241
    private String errorClass;    // H, S, O, U
    private String errorType;     // PERM, TEMP, PERF, PEND, INFO, UNKN
    private String label;         // ej: DISK_ERR4
    private String resource;      // ej: hdisk0
    private String description;   // texto libre
    private String rawMessage;
}