package com.aoa.aix.transform;

import io.opentelemetry.api.logs.Severity;
import org.springframework.stereotype.Component;

@Component
public class AixErrorClassifier {

    /**
     * Reglas:
     *  - Clase H (Hardware) + PERM  → FATAL
     *  - Clase H (Hardware) + TEMP  → ERROR
     *  - Clase S (Software) + PERM  → ERROR
     *  - PERF                       → WARN
     *  - PEND                       → WARN
     *  - INFO                       → INFO
     *  - default                    → INFO
     */
    public Severity classify(ErrptEvent e) {
        String cls = e.getErrorClass();
        String type = e.getErrorType();

        if ("H".equalsIgnoreCase(cls) && "PERM".equalsIgnoreCase(type)) {
            return Severity.FATAL;            // CRITICAL/FATAL
        }
        if ("H".equalsIgnoreCase(cls) && "TEMP".equalsIgnoreCase(type)) {
            return Severity.ERROR;
        }
        if ("S".equalsIgnoreCase(cls) && "PERM".equalsIgnoreCase(type)) {
            return Severity.ERROR;
        }
        return switch (type) {
            case "PERF", "PEND" -> Severity.WARN;
            case "INFO"         -> Severity.INFO;
            default             -> Severity.INFO;
        };
    }

    public boolean isCritical(ErrptEvent e) {
        Severity s = classify(e);
        return s == Severity.FATAL || s == Severity.ERROR;
    }
}