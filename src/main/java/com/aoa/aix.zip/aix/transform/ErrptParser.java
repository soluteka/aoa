package com.aoa.aix.transform;

import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class ErrptParser {

    // Formato posicional AIX errpt:
    //   errpt: <ID8hex> <FECHA10> <T> <C> <RESOURCE> <DESCRIPTION...>
    // Ej: errpt: AA8AB241 0508185626 P H hdisk0 DISK OPERATION ERROR
    private static final Pattern POSITIONAL = Pattern.compile(
            "errpt:\\s*([0-9A-Fa-f]{8})\\s+(\\d{10})\\s+([PTIUF])\\s+([HSOU])\\s+(\\S+)\\s+(.*)$"
    );

    // Fallback con etiquetas: class=H type=PERM ...
    private static final Pattern ID_HEX     = Pattern.compile("\\b([0-9A-Fa-f]{8})\\b");
    private static final Pattern CLASS_PAT  = Pattern.compile("\\bclass\\s*[:=]?\\s*([HSOU])\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern TYPE_PAT   = Pattern.compile("\\btype\\s*[:=]?\\s*(PERM|TEMP|PERF|PEND|INFO|UNKN)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern LABEL_PAT  = Pattern.compile("\\blabel\\s*[:=]?\\s*([A-Z0-9_]+)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern RESOURCE_PAT = Pattern.compile("\\bresource\\s*[:=]?\\s*(\\S+)", Pattern.CASE_INSENSITIVE);

    private static final Map<String, String> TYPE_MAP = Map.of(
            "P", "PERM",
            "T", "TEMP",
            "I", "INFO",
            "U", "UNKN",
            "F", "PERF"
    );

    public ErrptEvent parse(String raw) {
        if (raw == null) raw = "";

        Matcher m = POSITIONAL.matcher(raw);
        if (m.find()) {
            String id       = m.group(1).toUpperCase();
            String typeChar = m.group(3).toUpperCase();
            String klass    = m.group(4).toUpperCase();
            String resource = m.group(5);
            String desc     = m.group(6).trim();

            return ErrptEvent.builder()
                    .errorId(id)
                    .errorClass(klass)
                    .errorType(TYPE_MAP.getOrDefault(typeChar, "UNKN"))
                    .label(desc.replaceAll("\\s+", "_").toUpperCase())
                    .resource(resource)
                    .description(desc)
                    .rawMessage(raw)
                    .build();
        }

        // Fallback: formato con etiquetas key=value
        return ErrptEvent.builder()
                .errorId(find(ID_HEX, raw, "00000000").toUpperCase())
                .errorClass(find(CLASS_PAT, raw, "U").toUpperCase())
                .errorType(find(TYPE_PAT, raw, "UNKN").toUpperCase())
                .label(find(LABEL_PAT, raw, "UNKNOWN"))
                .resource(find(RESOURCE_PAT, raw, "unknown"))
                .description(raw)
                .rawMessage(raw)
                .build();
    }

    private String find(Pattern p, String text, String def) {
        Matcher m = p.matcher(text);
        return m.find() ? m.group(1) : def;
    }
}