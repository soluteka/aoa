package com.aoa.aix.ingest.lparstat;

import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.common.AttributeKey;
import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.metrics.DoubleGauge;
import io.opentelemetry.api.metrics.Meter;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class LparstatService {

    private final OpenTelemetry openTelemetry;
    private final XmlMapper xmlMapper = new XmlMapper();

    @Value("${aix.lparstat.command}")
    private String command;

    private DoubleGauge cpuUser, cpuSys, cpuWait, cpuIdle, physc, entc;

    @PostConstruct
    void initMetrics() {
        Meter meter = openTelemetry.getMeter("aix.lparstat");
        cpuUser = meter.gaugeBuilder("aix.cpu.user").setUnit("%").build();
        cpuSys  = meter.gaugeBuilder("aix.cpu.sys").setUnit("%").build();
        cpuWait = meter.gaugeBuilder("aix.cpu.wait").setUnit("%").build();
        cpuIdle = meter.gaugeBuilder("aix.cpu.idle").setUnit("%").build();
        physc   = meter.gaugeBuilder("aix.cpu.physc").setUnit("cores").build();
        entc    = meter.gaugeBuilder("aix.cpu.entc").setUnit("%").build();
    }

    /** Ejecuta lparstat -X periódicamente. */
    @Scheduled(fixedDelayString = "${aix.lparstat.interval-ms}")
    public void collect() {
        try {
            String xml = runCommand(command);
            if (xml == null || xml.isBlank()) return;

            LparstatModel model = xmlMapper.readValue(xml, LparstatModel.class);
            publish(model);
        } catch (Exception e) {
            log.error("Error ejecutando/parsing lparstat -X", e);
        }
    }

    private void publish(LparstatModel m) {
        if (m.getUtilization() == null) return;

        Attributes attrs = Attributes.builder()
                .put(AttributeKey.stringKey("lpar.type"),
                        m.getSystemConfig() != null ? m.getSystemConfig().getType() : "unknown")
                .put(AttributeKey.stringKey("lpar.mode"),
                        m.getSystemConfig() != null ? m.getSystemConfig().getMode() : "unknown")
                .build();

        var u = m.getUtilization();
        if (u.getUser()  != null) cpuUser.set(u.getUser(),  attrs);
        if (u.getSys()   != null) cpuSys.set(u.getSys(),    attrs);
        if (u.getWait()  != null) cpuWait.set(u.getWait(),  attrs);
        if (u.getIdle()  != null) cpuIdle.set(u.getIdle(),  attrs);
        if (u.getPhysc() != null) physc.set(u.getPhysc(),   attrs);
        if (u.getEntc()  != null) entc.set(u.getEntc(),     attrs);
    }

    private String runCommand(String cmd) throws Exception {
        Process p = new ProcessBuilder("sh", "-c", cmd)
                .redirectErrorStream(true)
                .start();
        try (BufferedReader r = new BufferedReader(
                new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
            String out = r.lines().collect(Collectors.joining("\n"));
            p.waitFor();
            return out;
        }
    }
}