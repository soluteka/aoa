package com.aoa.aix.ingest.syslog;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.ip.tcp.connection.AbstractServerConnectionFactory;
import org.springframework.integration.ip.tcp.connection.TcpNioServerConnectionFactory;
import org.springframework.integration.ip.udp.UnicastReceivingChannelAdapter;
import org.springframework.integration.syslog.inbound.TcpSyslogReceivingChannelAdapter;
import org.springframework.integration.syslog.inbound.UdpSyslogReceivingChannelAdapter;
import org.springframework.messaging.MessageChannel;

@Slf4j
@Configuration
public class SyslogIngestConfig {

    @Value("${aix.syslog.udp-port:1514}")
    private int udpPort;

    @Value("${aix.syslog.tcp-port:1514}")
    private int tcpPort;

    @PostConstruct
    public void init() {
        log.info("SyslogIngestConfig: udpPort={}, tcpPort={}", udpPort, tcpPort);
    }

    @Bean
    public MessageChannel syslogInputChannel() {  // ← antes era syslogChannel
        return new DirectChannel();
    }

    // ── UDP ──
    @Bean
    public UnicastReceivingChannelAdapter udpReceiver() {
        UnicastReceivingChannelAdapter r = new UnicastReceivingChannelAdapter(udpPort);
        r.setAutoStartup(false); // lo arranca el Syslog adapter
        return r;
    }

    @Bean(initMethod = "start")
    public UdpSyslogReceivingChannelAdapter udpSyslogAdapter(
            UnicastReceivingChannelAdapter udpReceiver,
            @Qualifier("syslogInputChannel") MessageChannel syslogInputChannel) {
        UdpSyslogReceivingChannelAdapter a = new UdpSyslogReceivingChannelAdapter();
        a.setUdpAdapter(udpReceiver);
        a.setOutputChannel(syslogInputChannel);
        a.setAutoStartup(true);
        log.info("UDP Syslog adapter configured on port {}", udpPort);
        return a;
    }

    // ── TCP ──
    @Bean
    public AbstractServerConnectionFactory tcpConnectionFactory() {
        TcpNioServerConnectionFactory f = new TcpNioServerConnectionFactory(tcpPort);
        return f;
    }

    @Bean(initMethod = "start")
    public TcpSyslogReceivingChannelAdapter tcpSyslogAdapter(
            AbstractServerConnectionFactory tcpConnectionFactory,
            @Qualifier("syslogInputChannel") MessageChannel syslogInputChannel) {
        TcpSyslogReceivingChannelAdapter a = new TcpSyslogReceivingChannelAdapter();
        a.setConnectionFactory(tcpConnectionFactory);
        a.setOutputChannel(syslogInputChannel);
        a.setAutoStartup(true);
        log.info("TCP Syslog adapter configured on port {}", tcpPort);
        return a;
    }
}