package com.aoa.aix.ingest.memory;

import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.common.AttributeKey;
import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.metrics.DoubleGauge;
import io.opentelemetry.api.metrics.LongCounter;
import io.opentelemetry.api.metrics.Meter;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class MemoryAlertService {

    private static final double PAGING_THRESHOLD = 70.0;

    private final OpenTelemetry openTelemetry;

    private DoubleGauge pagingUsageGauge;
    private DoubleGauge pageInsGauge;
    private DoubleGauge pageOutsGauge;
    private LongCounter predictiveAlertCounter;

    @PostConstruct
    void init() {
        Meter meter = openTelemetry.getMeter("aix.memory");
        pagingUsageGauge = meter.gaugeBuilder("aix.memory.paging.usage")
                .setUnit("%").setDescription("Uso de Paging Space (%)").build();
        pageInsGauge = meter.gaugeBuilder("aix.memory.paging.pi")
                .setUnit("pages/s").setDescription("Page-ins por segundo").build();
        pageOutsGauge = meter.gaugeBuilder("aix.memory.paging.po")
                .setUnit("pages/s").setDescription("Page-outs por segundo").build();
        predictiveAlertCounter = meter.counterBuilder("aix.memory.alert.predictive")
                .setDescription("Alertas predictivas de memoria/paginación").build();
    }

    @Scheduled(fixedDelayString = "${aix.memory.interval-ms:60000}")
    public void collect() {
        try {
            double usage = parsePagingUsage(run("lsps -s"));
            double[] pipo = parseVmstat(run("vmstat 1 2"));   // pi, po
            double pi = pipo[0], po = pipo[1];

            Attributes base = Attributes.builder()
                    .put(AttributeKey.stringKey("source"), "aix").build();

            pagingUsageGauge.set(usage, base);
            pageInsGauge.set(pi, base);
            pageOutsGauge.set(po, base);

            boolean pagingActive = (pi > 0 || po > 0);
            boolean overThreshold = usage > PAGING_THRESHOLD;

            if (overThreshold || pagingActive) {
                String reason = overThreshold && pagingActive ? "threshold+active"
                        : overThreshold ? "threshold" : "active";
                Attributes alertAttrs = Attributes.builder()
                        .put(AttributeKey.stringKey("alert.reason"), reason)
                        .put(AttributeKey.doubleKey("paging.usage"), usage)
                        .put(AttributeKey.doubleKey("paging.pi"), pi)
                        .put(AttributeKey.doubleKey("paging.po"), po)
                        .build();
                predictiveAlertCounter.add(1, alertAttrs);

                log.warn("ALERTA PREDICTIVA memoria AIX: usage={}% pi={} po={} reason={}",
                        usage, pi, po, reason);
            }
        } catch (Exception e) {
            log.error("Error recolectando métricas de memoria AIX", e);
        }
    }

    /** lsps -s →  "Total Paging Space   Percent Used\n  512MB                70%" */
    private double parsePagingUsage(String out) {
        Matcher m = Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*%").matcher(out);
        return m.find() ? Double.parseDouble(m.group(1)) : 0.0;
    }

    /** vmstat → última línea, columnas pi (col 6) y po (col 7). */
    private double[] parseVmstat(String out) {
        String[] lines = out.strip().split("\\R");
        for (int i = lines.length - 1; i >= 0; i--) {
            String[] tok = lines[i].trim().split("\\s+");
            if (tok.length >= 7) {
                try {
                    double pi = Double.parseDouble(tok[5]);
                    double po = Double.parseDouble(tok[6]);
                    return new double[]{pi, po};
                } catch (NumberFormatException ignored) { }
            }
        }
        return new double[]{0, 0};
    }

    private String run(String cmd) throws Exception {
        Process p = new ProcessBuilder("sh", "-c", cmd)
                .redirectErrorStream(true).start();
        try (BufferedReader r = new BufferedReader(
                new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
            String out = r.lines().collect(Collectors.joining("\n"));
            p.waitFor();
            return out;
        }
    }
}