package com.aoa.aix.ingest.lparstat;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import lombok.Data;

@Data
@JacksonXmlRootElement(localName = "lparstat")
public class LparstatModel {

    @JacksonXmlProperty(localName = "system_config")
    private SystemConfig systemConfig;

    @JacksonXmlProperty(localName = "utilization")
    private Utilization utilization;

    @Data public static class SystemConfig {
        @JacksonXmlProperty(isAttribute = true) private String type;
        @JacksonXmlProperty(isAttribute = true) private String mode;
        @JacksonXmlProperty(isAttribute = true) private String smt;
        @JacksonXmlProperty(isAttribute = true) private Double ent;
    }

    @Data public static class Utilization {
        @JacksonXmlProperty(localName = "user")  private Double user;
        @JacksonXmlProperty(localName = "sys")   private Double sys;
        @JacksonXmlProperty(localName = "wait")  private Double wait;
        @JacksonXmlProperty(localName = "idle")  private Double idle;
        @JacksonXmlProperty(localName = "physc") private Double physc;
        @JacksonXmlProperty(localName = "entc")  private Double entc;
        @JacksonXmlProperty(localName = "lbusy") private Double lbusy;
        @JacksonXmlProperty(localName = "vcsw")  private Double vcsw;
        @JacksonXmlProperty(localName = "phint") private Double phint;
    }
}