package com.aoa.aix.ingest.syslog;

import com.aoa.aix.transform.AixErrorClassifier;
import com.aoa.aix.transform.ErrptEvent;
import com.aoa.aix.transform.ErrptParser;
import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.common.AttributeKey;
import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.logs.Logger;
import io.opentelemetry.api.logs.Severity;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class SyslogMessageHandler {

    private final OpenTelemetry openTelemetry;
    private final ErrptParser errptParser;
    private final AixErrorClassifier classifier;

    @ServiceActivator(inputChannel = "syslogInputChannel")
    public void handle(Message<?> message) {
        String payload = String.valueOf(message.getPayload());
        ErrptEvent event = errptParser.parse(payload);
        Severity severity = classifier.classify(event);

        Logger otelLogger = openTelemetry.getLogsBridge()
                .loggerBuilder("aix.errpt").build();

        Attributes attrs = Attributes.builder()
                // ── Mapeo semántico OTLP ──
                .put(AttributeKey.stringKey("aix.error.id"),    event.getErrorId())
                .put(AttributeKey.stringKey("aix.error.class"), event.getErrorClass())
                .put(AttributeKey.stringKey("aix.error.type"),  event.getErrorType())
                .put(AttributeKey.stringKey("aix.error.label"), event.getLabel())
                .put(AttributeKey.stringKey("aix.resource"),    event.getResource())
                .put(AttributeKey.stringKey("aix.host"),
                        String.valueOf(message.getHeaders().get("syslog_HOST")))
                .put(AttributeKey.booleanKey("aix.error.critical"),
                        classifier.isCritical(event))
                .build();

        otelLogger.logRecordBuilder()
                .setSeverity(severity)
                .setSeverityText(severity.name())
                .setBody(event.getDescription())
                .setAllAttributes(attrs)
                .emit();

        log.debug("errpt -> OTLP [{}] id={} class={} type={}",
                severity, event.getErrorId(), event.getErrorClass(), event.getErrorType());
    }
}