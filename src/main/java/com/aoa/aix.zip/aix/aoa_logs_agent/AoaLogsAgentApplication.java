package com.aoa.aix.aoa_logs_agent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication(scanBasePackages = "com.aoa.aix")
@EnableScheduling
public class AoaLogsAgentApplication {

    public static void main(String[] args) {
        SpringApplication.run(AoaLogsAgentApplication.class, args);
    }
}